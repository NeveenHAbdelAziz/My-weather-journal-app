# Weather-Journal App Project

## Overview
This project requires you to create an asynchronous web app that uses Web API and user data to dynamically update the UI. 

## Instructions
This will require modifying the `server.js` file and the `website/app.js` file. You can see `index.html` for element references, and once you are finished with the project steps, you can use `style.css` to style your application to customized perfection.

## Extras
If you are interested in testing your code as you go, you can use `tests.js` as a template for writing and running some basic tests for your code.

## Project Description
Node and Express installed on the local machine.
The ‘cors’ package installed in the project.
The body-parser package installed and included in the project.
API credentials on OpenWeatherMap.com created.
There is a GET route setup on the server side to return JS object.
There is an asynchronous function to fetch the data from the app endpoint.
This App has the ability to add an entry to the project endpoint using a POST route setup on the server side. 
The server side function create a new entry in the apps endpoint (JS object) consisting of the data received from the client side POST.
This App has an event listener to an existing HTML button.
This App Dynamically Update UI according to data returned by the app route and app’s data on the client side.