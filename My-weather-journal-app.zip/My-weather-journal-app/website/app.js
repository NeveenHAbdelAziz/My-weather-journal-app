/* Global Variables */
// Personal API Key for OpenWeatherMap API
const apiKey ='e587d38af9e3c17fa06b46aa85767fe6';

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+1 +'.'+ d.getDate()+'.'+ d.getFullYear();

const zipCode = document.getElementById('zip');
// Event listener to add function to existing HTML DOM element
document.getElementById('generate').addEventListener('click', async ()=>{

       try{    
        const baseUrl = `https://api.openweathermap.org/data/2.5/weather?zip=${zipCode.value}&appid=${apiKey}&units=metric`;
     // The API Key variable is passed as a parameter to fetch()
        apiResponse = await fetch (baseUrl);
        const resData = await apiResponse.json();
        const temp = resData.main.temp;
        const cityName = resData.name;
        const feelings = document.getElementById('feelings');
        
   // POST data
        await fetch('/saveData',{
        method: 'POST', 
        credentials: 'same-origin',
        headers: {
        'Content-Type': 'application/json',
        }, 
        body: JSON.stringify({date: newDate, 
                                feelings : feelings.value , 
                                temp })
        });

     // fetch the data from the app endpoint GET Web API Data
        getResponse = await fetch('/getData');
        const getRes = await getResponse.json();

     // Dynamically Update UI and Set the properties of existing HTML elements 
        document.getElementById('date').innerHTML=`Date : ${getRes.date} , City Name :  ${cityName}`;
        document.getElementById('temp').innerHTML=`Temprature : ${getRes.temp} C `;
        document.getElementById('content').innerHTML=`I'm feeling ${getRes.feelings} today.`;
          
       }catch(err){
          console.log('There is an error! please enter Zip Code ');
          alert("Please enter Zip Code");
       }
    
});