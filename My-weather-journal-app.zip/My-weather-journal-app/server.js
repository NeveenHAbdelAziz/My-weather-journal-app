// Setup empty JS object to act as endpoint for all routes
projectData = {};

// Require Express to run server and routes
const express = require ('express');

// Start up an instance of app
const app = express();

/* Middleware*/
//Here we are configuring express to use body-parser as middle-ware.
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Cors for cross origin allowance
const cors = require('cors');
app.use(cors());

// Initialize the main project folder
app.use(express.static('website'));


// Setup Server
port = 8000;

const server = app.listen(port , ()=>{
    console.log(`Server is up and working on port ${port}`);
});
//GET route setup to return the JS object created at the top of server code
app.get ('/getData',(request,response)=>{
response.send(projectData);
});
//add an entry to the project endpoint using a POST route setup
app.post ('/saveData',(request,response)=>{
    projectData = request.body ;
    response.send();
})